const todoList = document.querySelector('.todo-list');
const root = document.querySelector('#todo');
const formAddTodo = document.querySelector('#form-add-todo');
const body = document.body;


function generateTodo(title, checked) {
    return `
    <li>

    <label class="toggleButton"> 
    <input class='todo-checkbox' data-action='CHECKED' type="checkbox" ${checked == true ? 'checked' : ''}>
    <div>
      <svg viewBox="0 0 44 44">
        <path
          d="M14,24 L21,31 L39.7428882,11.5937758 C35.2809627,6.53125861 30.0333333,4 24,4 C12.95,4 4,12.95 4,24 C4,35.05 12.95,44 24,44 C35.05,44 44,35.05 44,24 C44,19.3 42.5809627,15.1645919 39.7428882,11.5937758"
          transform="translate(-2.000000, -2.000000)"></path>
      </svg>
    </div>
  </label>

    <h2 class="title ${checked ? 'active' : ''}">${title}</h2>

    <button data-action='TODO_EDIT' class="btn-edit">
    <svg data-action='TODO_EDIT' class="icon-edit" x="0px" y="0px"
    viewBox="0 0 468.134 468.134" style="enable-background:new 0 0 468.134 468.134;" xml:space="preserve">
<path data-action='TODO_EDIT' style="fill:#DC8744;" d="M28.06,363.046L9.317,423.983l-8.763,28.468c-2.859,9.288,5.842,17.989,15.13,15.129l28.467-8.763
   l60.939-18.743L28.06,363.046z"/>
<path data-action='TODO_EDIT' style="fill:#3A556A;" d="M44.151,458.817l-28.467,8.763c-9.288,2.859-17.988-5.841-15.129-15.129l8.763-28.468L44.151,458.817
   z"/>
<rect data-action='TODO_EDIT' x="-19.151" y="194.604" transform="matrix(-0.7071 0.7071 -0.7071 -0.7071 511.5694 231.7721)" style="fill:#FCD462;" width="453.868" height="54.465"/>
<rect data-action='TODO_EDIT' x="19.36" y="233.116" transform="matrix(-0.7071 0.7071 -0.7071 -0.7071 604.5447 270.2841)" style="fill:#F6C358;" width="453.868" height="54.465"/>
<path data-action='TODO_EDIT' style="fill:#E56353;" d="M426.039,119.122L349.01,42.094l38.436-38.436c4.877-4.877,12.784-4.877,17.66,0l59.368,59.368
   c4.877,4.877,4.877,12.784,0,17.66L426.039,119.122z"/>

   
       <rect data-action='TODO_EDIT' x="352.212" y="52.373" transform="matrix(-0.7071 0.7071 -0.7071 -0.7071 692.3092 -73.0846)" style="fill:#EBF0F3;" width="18.157" height="108.937"/>
   
       <rect data-action='TODO_EDIT' x="326.525" y="78.036" transform="matrix(-0.7071 0.7071 -0.7071 -0.7071 666.604 -11.1108)" style="fill:#EBF0F3;" width="18.157" height="108.937"/>

</svg>

    </button>
    <button data-action='TODO_DELETE' class="btn-delete">
    <svg class="icon-delete" data-action='TODO_DELETE' height="512pt" viewBox="0 0 512 512" width="512pt" xmlns="http://www.w3.org/2000/svg"><path data-action='TODO_DELETE' d="m256 0c-141.164062 0-256 114.835938-256 256s114.835938 256 256 256 256-114.835938 256-256-114.835938-256-256-256zm0 0" fill="#f44336"/><path d="m350.273438 320.105469c8.339843 8.34375 8.339843 21.824219 0 30.167969-4.160157 4.160156-9.621094 6.25-15.085938 6.25-5.460938 0-10.921875-2.089844-15.082031-6.25l-64.105469-64.109376-64.105469 64.109376c-4.160156 4.160156-9.621093 6.25-15.082031 6.25-5.464844 0-10.925781-2.089844-15.085938-6.25-8.339843-8.34375-8.339843-21.824219 0-30.167969l64.109376-64.105469-64.109376-64.105469c-8.339843-8.34375-8.339843-21.824219 0-30.167969 8.34375-8.339843 21.824219-8.339843 30.167969 0l64.105469 64.109376 64.105469-64.109376c8.34375-8.339843 21.824219-8.339843 30.167969 0 8.339843 8.34375 8.339843 21.824219 0 30.167969l-64.109376 64.105469zm0 0" fill="#fafafa"/></svg>
    </button>
    </li>
    `
}

function checkSaveActive(el) {
    const SearhSaveBtn = todoList.querySelector('#btn-save');
    if (SearhSaveBtn !== null) {
        eventLog(false, 'Please, confim save')
        return true;
    }
}

function editTodo(el) {
    const selectAllButtons = root.querySelectorAll('button');
    const todoCheckboxes = root.querySelectorAll('.todo-checkbox');
    for (btn of selectAllButtons) {
        btn.disabled = true;
    }
    for (checkbox of todoCheckboxes) {
        checkbox.disabled = true;
    }

    const oldTitle = el.querySelector('h2.title');
    const oldButton = el.querySelector('button.btn-edit');
    const deleteButton = el.querySelector('button.btn-delete');
    deleteButton.style.display = 'none';

    const inputEdit = document.createElement("input");
    inputEdit.setAttribute('placeholder', 'Input new title')
    inputEdit.setAttribute('class', 'new-title')
    inputEdit.setAttribute('value', oldTitle.textContent)
    const btnSave = document.createElement('button');
    btnSave.setAttribute('data-action', 'TODO_SAVE');
    btnSave.setAttribute('id', 'btn-save');
    btnSave.innerHTML = `
    
<svg class="icon-save"  x="0px" y="0px"
viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
<path style="fill:#72A3FC;" d="M507.606,84.394l-80-80C424.793,1.581,420.978,0,417,0H15C6.716,0,0,6.716,0,15v482
c0,8.284,6.716,15,15,15h482c8.284,0,15-6.716,15-15V95C512,91.022,510.419,87.207,507.606,84.394z"/>
<path style="fill:#2892FC;" d="M507.606,84.394l-80-80C424.793,1.581,420.978,0,417,0H256v512h241c8.284,0,15-6.716,15-15V95
C512,91.022,510.419,87.207,507.606,84.394z"/>
<path style="fill:#F9F9F9;" d="M406,242H106c-8.284,0-15,6.716-15,15v255h330V257C421,248.716,414.284,242,406,242z"/>
<path style="fill:#DFE4EA;" d="M421,257c0-8.284-6.716-15-15-15H256v270h165V257z"/>
<path style="fill:#FAD557;" d="M346,452H166c-8.284,0-15-6.716-15-15s6.716-15,15-15h180c8.284,0,15,6.716,15,15
   S354.284,452,346,452z"/>
<path style="fill:#FAD557;" d="M346,332H166c-8.284,0-15-6.716-15-15s6.716-15,15-15h180c8.284,0,15,6.716,15,15
   S354.284,332,346,332z"/>
<path style="fill:#FAD557;" d="M346,392H166c-8.284,0-15-6.716-15-15s6.716-15,15-15h180c8.284,0,15,6.716,15,15
   S354.284,392,346,392z"/>

<path style="fill:#5458EA;" d="M361,0H91v145c0,8.284,6.716,15,15,15h240c8.284,0,15-6.716,15-15V0z"/>
<path style="fill:#3545E3;" d="M256,0v160h90c8.284,0,15-6.716,15-15V0H256z"/>

<path style="fill:#FCB12B;" d="M346,422h-90v30h90c8.284,0,15-6.716,15-15S354.284,422,346,422z"/>
<path style="fill:#FCB12B;" d="M346,302h-90v30h90c8.284,0,15-6.716,15-15S354.284,302,346,302z"/>
<path style="fill:#FCB12B;" d="M346,362h-90v30h90c8.284,0,15-6.716,15-15S354.284,362,346,362z"/>


</svg>

    `;


    el.replaceChild(inputEdit, oldTitle)
    el.replaceChild(btnSave, oldButton)

    const btnSaved = el.querySelector('button[data-action="TODO_SAVE"]')

    btnSaved.addEventListener('click', () => {
        const newTitle = oldTitle;
        if(inputEdit.value.length < 4 || inputEdit.value.length > 18){
            eventLog(false, `Title is a short, or too large, min length 4 and max 18`)

            return;
        }
        for (btn of selectAllButtons) {
            btn.disabled = false;
        }
   
        newTitle.textContent = el.querySelector('input.new-title').value;
        eventLog(true, `Task has been renamed. <br> New title is "${newTitle.textContent}"`)

        el.replaceChild(newTitle, inputEdit)
        el.replaceChild(oldButton, btnSave)
        updatelocalStorage()
    });


}

function deleteTodo(el) {
    el.remove();
    eventLog(true, `Task "${el.querySelector('h2.title').textContent}" has been deleted`)
    updatelocalStorage()
}



function updatelocalStorage() {
    const getTodos = todoList.children;

    // clear old local storage
    localStorage.clear()

    // set new local storage keys and values
    let todoForLocalStorage = [];
    for (todo of getTodos) {
        todoForLocalStorage.push([todo.querySelector('h2.title').textContent, todo.querySelector('input[type=checkbox]').checked])
    }
    localStorage.setItem('todolist', JSON.stringify(todoForLocalStorage));
    loadFromLocalStorage()




}



function loadFromLocalStorage() {
    let todos = ''

    try {
        let getListFromLocalStorage = JSON.parse(localStorage.getItem('todolist'));
        for (localTodos of getListFromLocalStorage) {
            todos += generateTodo(localTodos[0], localTodos[1]);
        }
    } catch (error) {
        console.log(error)

    }
    todoList.innerHTML = todos;
}
function addTodo(e) {
    e.preventDefault();
    const form = e.target.closest('form');
    const formData = new FormData(form);
    const title = formData.get('todo-title');
    if (title.length < 4 || title.length > 18) {
        eventLog(false, `Title is a short, or too large, min length 4 and max 18`)
        return;
    }
    todoList.innerHTML += generateTodo(title, false);
    form.reset()

    eventLog(true, `Task "${title}" added to list, let's do it!`)

    updatelocalStorage();

}
function complited(el) {
    let currentElement = el.querySelector('input[type="checkbox"')
    currentElement == true ? currentElement.setAttribute('checked', 'false') : currentElement.setAttribute('checked', 'true')

    if (currentElement.checked) {
        eventLog(true, `Task ${el.querySelector('h2.title').textContent} completed, keep up!`)
    } else {
        eventLog(true, `Task ${el.querySelector('h2.title').textContent} uncompleted :(`)

    }

    setTimeout(() => {
        updatelocalStorage()
    }, 700);

}



function eventLog(result, bodyLog) {
    const eventLog = document.querySelector('.event-log');
    const eventResult = result == true ? 'successful' : 'error';
    const event = `
    <h3 class="log-title ${eventResult}">${eventResult.charAt(0).toUpperCase() + eventResult.slice(1)}</h3>
    <p class="log-body">
      ${bodyLog}
    </p>
    `
    const eventWindow = document.createElement('div');
    eventWindow.innerHTML = event;
    eventWindow.setAttribute('class', 'event-window')
    eventLog.appendChild(eventWindow);
    setTimeout(() => {
        eventWindow.remove()
    }, 3000);
}

function main() {
    loadFromLocalStorage()

    root.addEventListener('click', e => {
        if (checkSaveActive(e.target)) { return; }
        switch (e.target.dataset.action) {
            case 'TODO_EDIT':
                editTodo(e.target.closest('li'))
                break;
            case 'TODO_DELETE':
                deleteTodo(e.target.closest('li'))
                break;
            case 'TODO_ADD':
                addTodo(e)
                break;
            case 'CHECKED':
                complited(e.target.closest('li'))
                break;
        }
    });

}
main()






